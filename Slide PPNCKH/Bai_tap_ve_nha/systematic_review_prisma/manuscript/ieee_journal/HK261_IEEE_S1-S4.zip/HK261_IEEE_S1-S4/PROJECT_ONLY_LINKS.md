# Project-only links

These links are retained in source documents for provenance. Publisher PDFs are available under their access terms. Internal workflow records document upstream checks. The original report IDs, locators and accession data are in the packaged ledgers.

| Document | Project path |
| --- | --- |
| r0082_review.md | `restart_2026_11_26/synthesis/final_46/r0082_correction_review.md` |
| r0082_review.md | `restart_2026_11_26/synthesis/final_46/r0082_locator_review.md` |
| r0082_review.md | `restart_2026_11_26/synthesis/final_46/r0082_primary_review.md` |
| report.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0001.pdf` |
| report.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0113.pdf` |
| report.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0145.pdf` |
| report.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0223.pdf` |
| report.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0292.pdf` |
| report.md | `restart_2026_11_26/integrity/borderline_author_review/access-review.md` |
| report.md | `restart_2026_11_26/integrity/borderline_author_review/gemini-correction-receipt.json` |
| report.md | `restart_2026_11_26/integrity/borderline_author_review/gemini-initial-receipt.json` |
| report.md | `restart_2026_11_26/integrity/borderline_author_review/gemini-parent-correction-receipt.json` |
| report.md | `restart_2026_11_26/integrity/borderline_author_review/manifest.json` |
| supplement_s2_adjudication.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0113.pdf` |
| supplement_s2_adjudication.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0121.pdf` |
| supplement_s2_adjudication.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0125.pdf` |
| supplement_s3.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0003.pdf` |
| supplement_s3.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0019.pdf` |
| supplement_s3.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0036.pdf` |
| supplement_s3.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0080.pdf` |
| supplement_s3.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0090.pdf` |
| supplement_s3.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0092.pdf` |
| supplement_s3.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0118.pdf` |
| supplement_s3.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0121.pdf` |
| supplement_s3.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0125.pdf` |
| supplement_s3.md | `restart_2026_11_26/fulltext_retrieval/pdf/R0145.pdf` |
