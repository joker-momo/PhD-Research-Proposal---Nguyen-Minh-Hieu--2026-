# HK261 IEEE supplements S1–S4

Companion archive for the 17-page [IEEE manuscript](manuscript/ieee_journal/main.pdf), revised from Git commit `b62e51c`. This revision standardizes reference 22 (LLHR) in the bibliography and S4. The PDF is included as a versioned reference for the supplement page numbers. PRISMA remains 46 included, 90 excluded and zero awaiting classification.

| Item | Entry point |
| --- | --- |
| S1 · Search strategies and protocol | [Executed strategies](manuscript/sn_computer_science/supplement_search_strategies.md), [protocol](restart_2026_11_26/protocol_restart.md), [locked search manifest](restart_2026_11_26/search_dataset_manifest.json) and [normalized records](restart_2026_11_26/records_normalized.csv) |
| S2 · Eligibility and adjudication | [S2](manuscript/sn_computer_science/supplement_s2_adjudication.md), [frozen eligibility CSV](manuscript/sn_computer_science/supplement_s2_eligibility.csv) and [PRISMA counts](restart_2026_11_26/prisma/prisma_counts.json) |
| S3 · Study data and appraisal | [S3](manuscript/sn_computer_science/supplement_s3.md) |
| S4 · IEEE evidence and reproduction | [IEEE S4](manuscript/ieee_journal/supplement_s4.md) and [IEEE PRISMA checklist](manuscript/ieee_journal/prisma_2020_checklist.md) |

Shared source files keep their historical directory names to preserve S2 byte for byte. The included S3 copy routes its S4 links to the IEEE index. Publisher PDFs, raw vendor exports and internal workflow records are held in the project. For these materials, use report IDs, physical-page locators and provenance paths in the records provided here. See the [project-only link inventory](PROJECT_ONLY_LINKS.md) for references to these upstream files.

Methods and the acknowledgment in the IEEE manuscript describe the AI-assisted workflow and the documented reviewer roles. The [S4 screening workflow](manuscript/ieee_journal/supplement_s4.md#screening-workflow-provenance) links the title-and-abstract and full-text ledgers. The S2 register and source-check forms retain their recorded provenance.

## Verify and rebuild

Run from the directory containing this README.

```sh
shasum -a 256 -c SHA256SUMS
cd manuscript/ieee_journal
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The LaTeX build uses the included PRISMA figure PDF and the frozen generated tables and figures. PDF timestamps may differ on rebuild. The underlying study and source ledgers remain available for tracing the inputs.
