# Phiếu thẩm định HK261

## Xác nhận hai phiếu đối chiếu nguồn

[Hồ sơ S2](../../../../manuscript/sn_computer_science/supplement_s2_adjudication.md#author-statement-on-reviewer-responsibilities) ghi vai trò người đánh giá và nguồn gốc của hai phiếu xác nhận. Mỗi phiếu có 887 mục đối chiếu nguồn. Hai phiếu sàng lọc độc lập vẫn trống.

| Phiếu | Đối chiếu nguồn | Sàng lọc |
| --- | --- | --- |
| R1 | [CSV](R1/source_verification.csv) | [CSV](R1/screening.csv) |
| R2 | [CSV](R2/source_verification.csv) | [CSV](R2/screening.csv) |

[Bảng ánh xạ](coordinator/key.csv) nối mã phiếu với mã báo cáo.
