# S3. Study characteristics, appraisal, outcomes and S2 audit

| Need | Evidence |
| --- | --- |
| Find one of the 46 studies | [Study characteristics](../../restart_2026_11_26/synthesis/final_46/study_characteristics.csv), [source identity and SHA-256](../../restart_2026_11_26/synthesis/final_46/synthesis_input_index.csv), and [sources for individual technical-table cells](s4_study_row_sources.csv). |
| Check the R0082 source and relation to R0019 | [Source review](../../restart_2026_11_26/synthesis/final_46/r0082_review.md), [accepted field and appraisal evidence](../../restart_2026_11_26/synthesis/final_46/r0082_evidence.json), and [reconciliation script](../../restart_2026_11_26/synthesis/final_46/reconcile_inputs.py). |
| Check one engineering judgment | [460 judgments with rationales and original locators](../../restart_2026_11_26/synthesis/final_46/appraisal_rationale.csv). |
| Reconstruct the uniform RQ5 reread | [Pre-extraction rule](../../restart_2026_11_26/extraction/rq5_uniform/rule.md), [frozen PDF manifest](../../restart_2026_11_26/synthesis/final_46/outcome_manifest.json), [report coverage](../../restart_2026_11_26/synthesis/final_46/report_coverage.csv), and [outcome ledger](../../restart_2026_11_26/synthesis/final_46/outcomes.csv). |
| Check the quantitative prose and the two summary tables | [RQ5 claim sources](../../restart_2026_11_26/synthesis/final_46/rq5_claim_sources.csv), [mechanism and evaluation coding with original locators](../../restart_2026_11_26/synthesis/final_46/mechanisms.csv), and [table generator](build_editorial_evidence.py). |
| Check the nine illustrated comparisons | [S4 row map](../ieee_journal/supplement_s4.md#numerical-contrast-row-map) and [source-verified R0092 correction](../../restart_2026_11_26/synthesis/active_rq_p08_erratum_R0092.json). |
| Reproduce the S2 audit in Table 8 | [S2 log](human_adjudication_log.csv), [audit output](audit_summary.json), [generated LaTeX](adjudication_audit_table.tex), and [S4 derivations](../ieee_journal/supplement_s4.md#s2-audit-derivations). |

The [historical reread review](../../restart_2026_11_26/extraction/rq5_uniform/review.md) documents the source method. The final release filters the previous corpus by the approved PRISMA IDs, removes R0113 and adds the independently checked R0082 fields. R0292 remains included. The 105 numerical-ledger rows contain 51 matched, 46 descriptive, three held, three cross-references and two reference benchmark entries. The 97 retained study-outcome entries come from 35 studies, including 23 with matched entries. Eleven studies, including R0082 and R0145, have only plot-based eligible study outcomes under the extraction rule. R0145 also provides labeled benchmark reference values, recorded separately from study outcomes. The final corpus has zero studies with printed outcomes held at report level for unresolved context. Individual held rows remain listed. The inventory samples explicit outcomes and supplies no pooled effect.

R0082's bibliography identifies the IEEE proceedings publication. The archived extraction uses physical pages counted from one in the retained arXiv v1 PDF. All six field anchors, all ten appraisal anchors and all four result figure captions were cross-checked at the same physical pages in the author-supplied IEEE proceedings PDF. The [cross-check](../../restart_2026_11_26/synthesis/final_46/r0082_publisher_crosscheck.json) records the file fingerprints and results. Source review records overlap with R0019 and the distinct technical evaluations. Shared run provenance remains unresolved. The figure-only R0082 results contribute zero exact outcome entries.

The [S2 author statement](supplement_s2_adjudication.md#author-statement-on-reviewer-responsibilities) records that the author and a colleague assigned the appraisal ratings. The retained appraisal rationales and the R1/R2 records document the underlying source locators and the AI-assisted source reviews.

## Twelve priority decisions

The author resolved the 12 listed items after reviewing the AI-assisted comparison. The [decision ledger](../../restart_2026_11_26/integrity/source_review_887/r1_r2_reconciliation/author_decisions.csv) records the author confirmations. The [application data](../../restart_2026_11_26/synthesis/final_46/author_decision_application.json) record each coding change and open issue. Physical PDF pages are counted from one. The comparison did not repeat the extraction independently for all reports and did not change eligibility.

| Decision | Applied finding | Open evidence |
| --- | --- | --- |
| 1. R0003 D06 · PARTIAL | The number of requests and UAVs was varied. The sensitivity evidence supports Partial. [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0003.pdf), pp. 5–6, §V.B, Hình 2–3, Bảng 1. | Independent repetitions and within-setting dispersion are unreported. |
| 2. R0036 Q01 · MATCHED | SAC² reports 22% higher accumulated surveillance coverage than Random-to-upload (RU) at 20 Mbps. [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0036.pdf), pp. 12, §VI, Hình 8(a) và đoạn thảo luận. | — |
| 3. R0080 Q03 · PARTIAL | At 20 UAVs and 100 MHz, the prose reports 0.9% above GSUP and 1.5% above Raw-Only. [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0080.pdf), pp. 5–6, §IV.C, Hình 3; Bảng I để phân biệt thiết lập. | The relative-percent versus percentage-point calculation and GSUP in the prose versus GDUP in the figure legend remain unresolved. No plot-derived values enter the retained count. Table I is a separate 100 Mbps comparison. |
| 4. R0090 Q05 · DESCRIPTIVE | Figure 5 labels 91% task completion for AeroAgriNet at 20 UAVs. [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0090.pdf), pp. 5, Hình 5; Performance Parameters; mục H. Scalability under Load. | The prose describes throughput above 90%. The definitions table measures throughput as data processed per unit time, so the throughput percentage and modality attribution remain unresolved. |
| 5. R0092 Q02 · MATCHED | VGG-16 system-total energy was 1.477 ± 0.054 Wh for DDCI and 1.502 ± 0.048 Wh for Comm-Min. [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0092.pdf), pp. 13, Bảng V, nhóm VGG-16, cột Energy (Wh) và đoạn Energy overhead. | — |
| 6. R0118 t2_workload · BOUNDED | CIFAR-100 image classification is the representative instantiation in §VI.B, with MobileNetV3-Small expert models and a ResNet-50 comparator. The label is restricted to this configuration. [physical p. 9, §VI.B] [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0118.pdf), pp. 9, §VI.B Evaluation Results. | — |
| 7. R0121 t3_network_event_response · ANALYTICAL | Analytical model and preliminary specification. No simulation or empirical validation is reported. [physical pp. 7–8, Fig. 3 and Table 4] [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0121.pdf), pp. 7–8, Hình 3 và đoạn thảo luận; Bảng 4, hàng Maturity level. | The attribution of the probability input remains unresolved. Modeled results do not establish observed recovery. |
| 8. R0125 D09 · NOT_REPORTED | The original five-page PDF describes software tools and the test setup. Access to study implementation code, test video, or study-specific reproducibility artifacts is unreported within that PDF. [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0125.pdf), pp. 1–5, §III và phần cuối bài (trọng tâm trang 3 và 5). | — |
| 9. R0125 Q01 · CROSS_REFERENCE | The study reports 12.8 FPS with two workers at four threads each versus 6.9 FPS with one four-thread worker (1.85× as reported). The same two-worker point is counted once in Q02. [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0125.pdf), pp. 3, §IV.A và Bảng I; §IV.B và Hình 1. | — |
| 10. R0145 D06 · PARTIAL | Section 6.3 and Figure 12 compare 20 randomly generated edge–cloud scenarios. This supports scenario sensitivity. [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0145.pdf), pp. 18–19, §6.3 (trang 18), Hình 12 (trang 19). | Independent repetitions or dispersion within the same fixed setting are unreported. |
| 11. R0145 Q01 · REFERENCE | Figure 4 gives reference TTFT of 0.68 s (17/25 s) and 0.19 s (19/100 s) for DeepSeek-R1-Distill-Llama-8B and LLaMA-3.2-3B respectively. [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0145.pdf), pp. 8, 15, §3.4 (trang 8), Hình 4 cột TTFT màu xanh (trang 15). | Attribution to local measurements remains unresolved. |
| 12. R0145 Q02 · REFERENCE | Figure 4 gives reference TPOT of 1/53 s and 1/246 s for the same models, in that order. [Original PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0145.pdf), pp. 8, 15, §3.4 (trang 8), Hình 4 cột TPOT màu cam (trang 15). | Attribution to local measurements remains unresolved. |

## S2 audit of author decisions

The author endorsed the full set of **46 inclusions and 90 exclusions**. The [S2 final eligibility register](supplement_s2_eligibility.csv) gives the supporting reason and source locator for all 136 decisions. **Ten** reports have separately documented final author decisions. The other **126** reports have the set-level endorsement. Four changed status relative to the frozen AI ledger, so the two change fractions are **4/10**. The S2 log has zero paired independent human decisions. Observed agreement is unavailable. PRISMA reconciles 46 included, 90 excluded and zero awaiting classification. [S2](supplement_s2_adjudication.md) and [S4 derivations](../ieee_journal/supplement_s4.md#s2-audit-derivations) record the case-level evidence and calculation.

### Review responsibilities and evidence limits

| Stage | Documented role and evidence | Coverage limit |
| --- | --- | --- |
| Title and abstract | The author reported participation by the lead reviewer and a colleague. The screening ledger records one disposition per deduplicated record. | Item-level assignments and whether reviews were independent are undocumented. |
| Full text | The lead reviewer read and summarized the reports, endorsed all 136 final dispositions and recorded ten decisions separately. The colleague contributed judgments, as reported by the lead reviewer. | The register contains zero paired full-text decisions locked before reconciliation. The reported colleague contribution cannot be allocated by report from the archived records. |
| Extraction and checks | R1 and R2 record two endorsements, each covering 887 checks on the 46 included studies. R1 is the lead reviewer's endorsement. The lead reviewer relayed the colleague's R2 endorsement. S2 identifies the earlier checks and classifications and how the endorsements were recorded. | Independent duplicate extraction and the number of extractors per report are undocumented. The checks add zero eligibility decisions. |
| Engineering appraisal and priorities | The author attributes appraisal judgments to the lead reviewer and colleague. Appraisal rationales and locators are retained. The lead reviewer decided 12 priority extraction, coding and appraisal items against the source PDFs. | Per-report allocation and independent duplicate appraisal are undocumented. The adjudicated items concern evidence interpretation. |

See the [S2 author statement](supplement_s2_adjudication.md#author-statement-on-reviewer-responsibilities), the [two source-verification appendices](supplement_s2_adjudication.md#s2-appendix-r1-source-verification-record) and the [12 priority decisions](#twelve-priority-decisions).

## Unified coding and scope sensitivity

[Primary technical coding](technical_coding.psv) gives one unit and one modality per included report. The [reconciliation script](../../restart_2026_11_26/synthesis/final_46/reconcile_inputs.py) projects these two columns into [mechanisms.csv](../../restart_2026_11_26/synthesis/final_46/mechanisms.csv). The active mechanism table uses the same retained-outcome counts as report coverage. The updated model-family figure codes NetMoE as a CNN classifier for the representative configuration in Sect. VI.B and retains its expert-dispatch code. Tables 2 and 5 aggregate these same codes; Table 4 and Figures 2 and 4 use the primary ledger directly.

### Continuity correction for R0019

The [publisher-version PDF](../../restart_2026_11_26/fulltext_retrieval/pdf/R0019.pdf) (SHA-256 `cf3b03ea32b227fabed31d14fc41bcb5d6645db248d821bb576bb81cd10818f1`), physical p. 15 (printed p. 8199), Fig. 19 and its discussion, varies membership in simulation from three to four and then two UAVs. The plot gives average cumulative rewards by learning episode for a five-layer LeNet configuration and shows reconvergence after changes. The original does not establish a planned handoff of inference work or state already in progress, or the time to a correct resumed inference output. Code R0019 as **modeled reliability or stress** (`analytic`), with membership-change sensitivity as the subtype. Keep simulation as its evaluation modality.

| Figure 4 continuity category | Before | After |
| --- | ---: | ---: |
| Modeled reliability or stress | 4 | 5 |
| Planned reassignment | 4 | 3 |
| Link disruption or fallback | 5 | 5 |
| Controlled disconnection | 3 | 3 |
| Node unavailability | 5 | 5 |
| No qualifying evidence | 25 | 25 |
| Total | 46 | 46 |

The [generator](build_technical_survey.py) counts distinct report IDs by `resilience` in [primary coding](technical_coding.psv) and fills the [Figure 4 macros](../ieee_journal/technical_macros.tex). It draws the corresponding event and response cells in [Table 4](../ieee_journal/technical_evaluation.tex) from the same row. Only the continuity coding and descriptions of R0019 were changed. The included reports, outcomes, S2 eligibility and PRISMA accounting remain fixed.

| Scenario | Reports | Dispatch studies | Studies with retained entries | Retained entries | Matched entries |
| --- | ---: | ---: | ---: | ---: | ---: |
| Final corpus | 46 | 9 | 35 | 97 | 51 |
| Omit R0145 | 45 | 8 | 35 | 97 | 51 |
| Omit R0223 | 45 | 8 | 34 | 95 | 51 |
| Omit both | 44 | 7 | 34 | 95 | 51 |

[Computed scenarios](../../restart_2026_11_26/synthesis/final_46/scope_sensitivity.json) reuse the updated extraction and frozen eligibility. Each omission removes one software-simulation dispatch study. Omitting R0145 removes zero retained study-outcome entries, and omitting R0223 removes two descriptive entries. The official corpus and PRISMA disposition remain as adjudicated. No pooled effect was calculated.
