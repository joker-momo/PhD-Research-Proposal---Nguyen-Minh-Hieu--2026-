# HK261 systematic review coursework handoff

The package covers 46 included reports representing 46 studies, 87 full-text exclusions, three reports awaiting classification and one unretrieved report.

- [Compiled 13-page paper](manuscript/sn_computer_science/main.pdf)
- [Editable LaTeX and build instructions](manuscript/sn_computer_science/README.md)
- [PRISMA 2020 checklist with page locators](restart_2026_11_26/prisma/active_prisma_checklist.md)
- [Final integrity audit](restart_2026_11_26/integrity/active_final_integrity_audit.md)
- [Limitations and outstanding confirmations](restart_2026_11_26/integrity/active_limitations.md)

From the manuscript directory run `tectonic --keep-logs --keep-intermediates main.tex`. The tested engine is Tectonic 0.16.9. Use `--only-cached` with a locally available TeX bundle.

`SHA256SUMS.json` records every member's byte count and digest except the ledger itself. Source PDFs, database exports, raw native application payloads and credentials are outside the archive. The evidence index, data matrices and reconciler retain project-relative locators. Access to the full local HK261 workspace is required to resolve omitted sources or repeat the full reconciliation. The editable LaTeX builds from the enclosed assets.
