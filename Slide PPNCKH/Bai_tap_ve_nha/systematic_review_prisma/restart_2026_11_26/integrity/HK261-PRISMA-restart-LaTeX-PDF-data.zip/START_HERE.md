# HK261 coursework handoff

Open manuscript/sn_computer_science/main.pdf to read the review.
To build the LaTeX from these sources, run the command in
manuscript/sn_computer_science/README.md from that directory.

The bundled data comprise the complete checklist, reconciled counts and
derived review tables. Source locators identify records and original PDF
pages in the project audit. Raw database exports and full-text files
remain in the local evidence workspace. Some audit and checklist links point to
that workspace. The integrity audit documents the
coverage and limits of source checks. Author details await confirmation.
This is a coursework handoff and has not been sent to any journal.
